# Eeyore (EOIR) Scraper

Eeyore Scraper is a Firefox web extension that allows the bulk scraping of court information from https://portal.eoir.justice.gov

Once installed, you can input mutipleA-Numbers into the extension. It will search the website and record the relevant details, then deliver the results as a spreadsheet.

Watch the releases page for a release.
